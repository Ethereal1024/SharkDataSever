# 🎯 SharkDataServer - 全平台脚本总览

## 📁 脚本文件清单

### Windows 批处理脚本 (.bat)

| 文件名 | 功能 | 使用方法 |
|--------|------|----------|
| `start.bat` | 启动服务器 | 双击运行或 `.\start.bat` |
| `test-mqtt.bat` | MQTT 测试客户端 | 双击运行或 `.\test-mqtt.bat` |
| `test-udp.bat` | UDP 测试客户端 | 双击运行或 `.\test-udp.bat` |

### Linux/macOS Shell 脚本 (.sh)

| 文件名 | 功能 | 使用方法 |
|--------|------|----------|
| `start.sh` | 启动服务器 | `chmod +x start.sh && ./start.sh` |
| `test-mqtt.sh` | MQTT 测试客户端 | `chmod +x test-mqtt.sh && ./test-mqtt.sh` |
| `test-udp.sh` | UDP 测试客户端 | `chmod +x test-udp.sh && ./test-udp.sh` |
| `install-and-run.sh` | 交互式安装运行（推荐） | `chmod +x install-and-run.sh && ./install-and-run.sh` |

## 🚀 快速启动指南

### Windows 用户

```powershell
# 1. 启动服务器
双击 start.bat

# 2. 测试 MQTT（新窗口）
双击 test-mqtt.bat

# 3. 测试 UDP（新窗口）
双击 test-udp.bat
```

### Linux/macOS 用户

**方法一：交互式脚本（最简单）**
```bash
chmod +x install-and-run.sh
./install-and-run.sh
# 然后选择菜单选项
```

**方法二：独立脚本**
```bash
# 添加权限
chmod +x *.sh

# 启动服务器
./start.sh

# 测试 MQTT（新终端）
./test-mqtt.sh

# 测试 UDP（新终端）
./test-udp.sh
```

## 📋 脚本功能对比

### Windows 脚本特性

✅ 自动检测依赖
✅ 自动安装 npm 包
✅ 彩色输出（UTF-8）
✅ 双击即可运行
✅ 错误提示和暂停

### Linux/macOS 脚本特性

✅ 完整的环境检查
✅ 自动权限设置
✅ ANSI 彩色输出
✅ 交互式菜单（install-and-run.sh）
✅ 一键启动多终端
✅ 支持 tmux/screen
✅ 优雅的错误处理

## 🎨 脚本输出示例

### start.sh 输出
```
═══════════════════════════════════════════════════════
🚀 SharkDataServer 一键启动脚本
═══════════════════════════════════════════════════════

✅ Node.js 已安装: v18.17.0
✅ npm 已安装: 9.6.7

ℹ️  检查依赖...
✅ 依赖已安装

ℹ️  检查视频源文件...
✅ 找到 1 个视频文件

ℹ️  启动服务器...
```

### install-and-run.sh 菜单
```
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║       🚀 SharkDataServer 完整安装和运行脚本 🚀           ║
║                                                           ║
║    UDP 视频流 + MQTT 数据发送模拟服务器                   ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

╔═══════════════════════════════════════════════════════╗
║                    请选择操作                         ║
╚═══════════════════════════════════════════════════════╝

  1) 启动服务器
  2) 测试 MQTT 客户端
  3) 测试 UDP 视频流客户端
  4) 同时启动服务器和测试客户端 (推荐)
  5) 查看使用说明
  6) 退出

请输入选项 [1-6]:
```

## 🔧 脚本技术细节

### Windows 批处理脚本

**编码设置：**
```batch
chcp 65001 >nul  # UTF-8 编码支持中文
```

**依赖检查：**
```batch
if not exist "node_modules\" (
    call npm install
)
```

**错误处理：**
```batch
if errorlevel 1 (
    echo ❌ 错误信息
    pause
    exit /b 1
)
```

### Linux/macOS Shell 脚本

**Shebang：**
```bash
#!/bin/bash
```

**颜色定义：**
```bash
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'  # No Color
```

**环境检查：**
```bash
if ! command -v node &> /dev/null; then
    print_error "未检测到 Node.js"
    exit 1
fi
```

**信号处理：**
```bash
trap 'echo ""; print_info "正在停止..."; exit 0' INT TERM
```

## 📖 详细文档链接

- **Windows 用户**：查看 [INSTALL.md](./INSTALL.md)
- **Linux/macOS 用户**：查看 [LINUX-GUIDE.md](./LINUX-GUIDE.md)
- **通用说明**：查看 [README.md](./README.md)
- **快速开始**：查看 [QUICKSTART.md](./QUICKSTART.md)

## 🎯 推荐使用方式

### 初次使用

**Windows：**
1. 双击 `start.bat` 自动安装并启动

**Linux/macOS：**
1. 运行 `./install-and-run.sh` 使用交互式菜单

### 日常使用

**Windows：**
- 服务器：双击 `start.bat`
- 测试：双击 `test-mqtt.bat` 和 `test-udp.bat`

**Linux/macOS：**
- 服务器：`./start.sh`
- 测试：`./test-mqtt.sh` 和 `./test-udp.sh`

### 生产环境

**推荐使用 PM2：**
```bash
# 安装 PM2
npm install -g pm2

# 启动服务
pm2 start server.js --name shark-server

# 开机自启
pm2 startup
pm2 save
```

## ⚙️ 自定义脚本

### 修改 Windows 脚本

编辑 `.bat` 文件，使用记事本或任何文本编辑器：
```batch
notepad start.bat
```

### 修改 Linux/macOS 脚本

编辑 `.sh` 文件：
```bash
nano start.sh
# 或
vim start.sh
# 或
code start.sh  # VS Code
```

**注意：** 修改后确保文件仍有执行权限
```bash
chmod +x start.sh
```

## 🐛 常见问题

### Windows

**Q: 双击脚本闪退？**
A: 右键 → 编辑，查看脚本内容是否正确

**Q: 提示"系统找不到指定的路径"？**
A: 确保在项目根目录运行脚本

**Q: 中文乱码？**
A: 脚本已设置 UTF-8，如仍乱码请检查控制台设置

### Linux/macOS

**Q: Permission denied？**
A: 运行 `chmod +x *.sh` 添加执行权限

**Q: 找不到 Node.js？**
A: 安装 Node.js：
- Ubuntu: `sudo apt-get install nodejs npm`
- macOS: `brew install node`

**Q: 脚本在哪个目录运行？**
A: 必须在项目根目录（包含 server.js 的目录）

## 🎓 进阶使用

### 集成到系统服务

**Windows：**
使用任务计划程序创建开机启动任务

**Linux：**
创建 systemd 服务（参见 LINUX-GUIDE.md）

### Docker 部署

创建 `Dockerfile`：
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3333 3334
CMD ["node", "server.js"]
```

构建和运行：
```bash
docker build -t shark-server .
docker run -p 3333:3333 -p 3334:3334 shark-server
```

## 📊 性能对比

| 启动方式 | 速度 | 资源占用 | 适用场景 |
|---------|------|---------|---------|
| 批处理/Shell 脚本 | ⭐⭐⭐⭐⭐ | 低 | 开发测试 |
| npm start | ⭐⭐⭐⭐ | 低 | 日常使用 |
| PM2 | ⭐⭐⭐ | 中 | 生产环境 |
| Docker | ⭐⭐ | 高 | 容器化部署 |
| systemd | ⭐⭐⭐ | 低 | Linux 生产 |

## 🔗 相关资源

### 在线工具

- [MQTT 在线测试](http://mqtt-explorer.com/)
- [Protobuf 在线工具](https://protobuf-decoder.netlify.app/)
- [视频格式转换](https://cloudconvert.com/)

### 文档

- [Node.js 官方文档](https://nodejs.org/)
- [Bash 脚本指南](https://www.gnu.org/software/bash/manual/)
- [PowerShell 文档](https://docs.microsoft.com/powershell/)

## 📝 更新历史

### v1.0.0 (2025-11-29)

**Windows 脚本：**
- ✅ start.bat - 服务器启动
- ✅ test-mqtt.bat - MQTT 测试
- ✅ test-udp.bat - UDP 测试

**Linux/macOS 脚本：**
- ✅ start.sh - 服务器启动
- ✅ test-mqtt.sh - MQTT 测试
- ✅ test-udp.sh - UDP 测试
- ✅ install-and-run.sh - 交互式安装运行

**功能特性：**
- ✅ 自动依赖检测和安装
- ✅ 彩色输出和友好提示
- ✅ 完善的错误处理
- ✅ 跨平台支持

---

**选择你的平台，开始使用吧！** 🚀
