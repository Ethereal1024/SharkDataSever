# 快速启动指南

## 🎯 选择你的操作系统

### Windows 用户 → [跳转到 Windows 说明](#windows-快速启动)
### Linux/macOS 用户 → [跳转到 Linux 说明](#linuxmacos-快速启动)

---

## Windows 快速启动

### 第一步：安装依赖

打开 PowerShell，进入项目目录：

```powershell
cd c:\Users\Administrator\Desktop\SharkDataSever
npm install
```

等待所有依赖安装完成（可能需要几分钟）。

### 第二步：启动服务器

**方法一：双击启动（推荐）**
```
直接双击 start.bat 文件
```

**方法二：命令行启动**

```powershell
npm start
```

或者：

```powershell
node server.js
```

### 第三步：测试服务

#### 测试 MQTT 服务

**方法一：双击启动**
```
双击 test-mqtt.bat 文件
```

**方法二：命令行启动**

```powershell
cd c:\Users\Administrator\Desktop\SharkDataSever
node test-mqtt-client.js
```

你应该能看到每3秒接收到一次 Protobuf 格式的机器人数据。

#### 测试 UDP 视频流

**方法一：双击启动**
```
双击 test-udp.bat 文件
```

**方法二：命令行启动**

```powershell
cd c:\Users\Administrator\Desktop\SharkDataSever
node test-udp-client.js
```

你应该能看到持续接收到 HEVC 视频流数据包。

---

## Linux/macOS 快速启动

### 方法一：交互式安装脚本（最简单，推荐）

```bash
# 1. 进入项目目录
cd SharkDataSever

# 2. 添加执行权限
chmod +x install-and-run.sh

# 3. 运行交互式脚本
./install-and-run.sh
```

然后从菜单中选择操作：
- 选项 1：启动服务器
- 选项 2：测试 MQTT 客户端
- 选项 3：测试 UDP 视频流客户端
- 选项 4：同时启动所有服务（推荐）

### 方法二：使用独立脚本

#### 第一步：添加执行权限

```bash
chmod +x start.sh test-mqtt.sh test-udp.sh
```

#### 第二步：启动服务器

```bash
./start.sh
```

脚本会自动：
- ✅ 检查 Node.js 和 npm
- ✅ 安装依赖（如果需要）
- ✅ 检查视频源文件
- ✅ 启动服务器

#### 第三步：测试服务

**测试 MQTT（打开新终端）**
```bash
cd SharkDataSever
./test-mqtt.sh
```

**测试 UDP（再打开一个新终端）**
```bash
cd SharkDataSever
./test-udp.sh
```

### 方法三：手动启动

```bash
# 安装依赖
npm install

# 启动服务器
npm start

# 测试（新终端）
node test-mqtt-client.js
node test-udp-client.js
```

---

## 停止服务

在任何运行的窗口中按 `Ctrl+C` 即可停止服务。

---

## 📋 完整脚本列表

### Windows 脚本
- `start.bat` - 启动服务器
- `test-mqtt.bat` - MQTT 测试客户端
- `test-udp.bat` - UDP 测试客户端

### Linux/macOS 脚本
- `start.sh` - 启动服务器
- `test-mqtt.sh` - MQTT 测试客户端
- `test-udp.sh` - UDP 测试客户端
- `install-and-run.sh` - 交互式安装和运行（推荐）

---

## 故障排除

### 问题：找不到视频文件
**解决方案**：确保 `VideoSource` 文件夹中有视频文件（如 1111.mp4）

### 问题：端口被占用
**解决方案**：
- Windows: `netstat -ano | findstr :3333`
- Linux/macOS: `lsof -i :3333`

修改 `server.js` 中的端口配置，或关闭占用端口的程序

### 问题：Permission denied (Linux/macOS)
**解决方案**：
```bash
chmod +x *.sh
```

### 问题：依赖安装失败
**解决方案**：
```bash
# 清除缓存
npm cache clean --force

# Windows
Remove-Item -Recurse -Force node_modules
npm install

# Linux/macOS
rm -rf node_modules package-lock.json
npm install

# 或使用淘宝镜像
npm install --registry=https://registry.npmmirror.com
```

### 问题：FFmpeg 错误
**解决方案**：
1. 检查视频文件是否损坏
2. 尝试使用其他格式的视频文件
3. 等待自动重试（服务器会在5秒后重试）

---

## 📖 更多信息

### Windows 用户
- 详细安装说明：查看 [INSTALL.md](./INSTALL.md)
- 完整文档：查看 [README.md](./README.md)

### Linux/macOS 用户
- Linux 使用指南：查看 [LINUX-GUIDE.md](./LINUX-GUIDE.md)
- 脚本说明：查看 [SCRIPTS-GUIDE.md](./SCRIPTS-GUIDE.md)
- 完整文档：查看 [README.md](./README.md)

---

## 服务信息

- **MQTT Broker**: mqtt://127.0.0.1:3333
- **UDP 视频流**: 127.0.0.1:3334
- **MQTT 主题**: robot/data
- **数据格式**: Protobuf (定义在 proto/messages.proto)
- **视频编码**: HEVC (H.265)
- **发送频率**: 
  - MQTT: 每3秒一次
  - UDP: 实时流式传输

---

## 🎉 开始使用

选择适合你的操作系统的方法，立即开始吧！

**Windows 用户**：双击 `start.bat` 即可开始
**Linux/macOS 用户**：运行 `./install-and-run.sh` 使用交互式菜单

---

## 下一步

查看 `README.md` 了解更多详细信息和高级配置选项。
